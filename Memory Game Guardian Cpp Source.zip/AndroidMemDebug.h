#ifndef _ANDROIDMEMDEBUG_H_
#define _ANDROIDMEMDEBUG_H_
#include <stdio.h>
#include <stdlib.h>
#include <sys/uio.h>
#include <sys/types.h>
#include <sys/syscall.h>
#include <pthread.h>
#include <unistd.h>
#include <dirent.h>
#include <fcntl.h>
#include <iostream>
#include "AndroidMemDebug.cpp"

enum{
	DWORD,
	FLOAT,
	BYTE,
	WORD,
	QWORD,
	XOR,
	DOUBLE,
};

enum{
	Mem_Auto,
	Mem_A,
	Mem_Ca,
	Mem_Cd,
	Mem_Cb,
	Mem_Jh,
	Mem_J,
	Mem_S,
	Mem_V,
	Mem_Xa,
	Mem_Xs,
	Mem_As,
	Mem_B,
	Mem_O,
};

struct MemPage
{
	long start;
	long end;
	char flags[8];
	char name[128];
	void *buf = NULL;
};

struct AddressData
{
	long *addrs = NULL;
	int count = 0;
};

size_t judgSize(int type){
	switch (type)
	{
	case DWORD:
	case FLOAT:
	case XOR:
		return 4;
	case BYTE:
		return sizeof(char);
	case WORD:
		return sizeof(short);
	case QWORD:
		return sizeof(long);
	case DOUBLE:
		return sizeof(double);
	}
	return 4;
}


int memContrast(char *str){
	if (strlen(str) == 0)
		return Mem_A;
	if (strstr(str, "/dev/ashmem/") != NULL)
		return Mem_As;
	if (strstr(str, "/system/fonts/") != NULL)
		return Mem_B;
	if (strstr(str, "/data/app/") != NULL)
		return Mem_Xa;
	if (strstr(str, "/system/framework/") != NULL)
		return Mem_Xs;
	if (strcmp(str, "[anon:libc_malloc]") == 0)
		return Mem_Ca;
	if (strstr(str, ":bss") != NULL)
		return Mem_Cb;
	if (strstr(str, "/data/data/") != NULL)
		return Mem_Cd;
	if (strstr(str, "[anon:dalvik") != NULL)
		return Mem_J;
	if (strcmp(str, "[stack]") == 0)
		return Mem_S;
	if (strcmp(str, "/dev/kgsl-3d0") == 0)
		return Mem_V;
	return Mem_O;
}



class MemoryDebug{
  private:
	pid_t pid = 0;
  public:
    int setPackageName(const char* name);
    long getModuleBase(const char* name,int index = 1);
	long getBssModuleBase(const char *name);
	size_t preadv(long address, void *buffer, size_t size);
	size_t pwritev(long address, void *buffer, size_t size);
	template < class T > AddressData search(T value, int type, int mem, bool debug = false);
	template < class T > int edit(T value,long address,int type,bool debug = false);
	int ReadDword(long address);
	long ReadDword64(long address);
	float ReadFloat(long address);
	long ReadLong(long address);
};


#endif///CMODSMEMORY.H